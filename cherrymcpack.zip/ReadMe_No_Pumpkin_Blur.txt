 _   _        ______                      _    _       
| \ | |       | ___ \                    | |  (_)      
|  \| | ___   | |_/ /   _ _ __ ___  _ __ | | ___ _ __  
| . ` |/ _ \  |  __/ | | | '_ ` _ \| '_ \| |/ / | '_ \ 
| |\  | (_) | | |  | |_| | | | | | | |_) |   <| | | | |
\_| \_/\___/  \_|   \__,_|_| |_| |_| .__/|_|\_\_|_| |_|
                                   | |                 
                                   |_|                 
______ _            _                                  
| ___ \ |          | |                                 
| |_/ / |_   _ _ __| |                                 
| ___ \ | | | | '__| |                                 
| |_/ / | |_| | |  |_|                                 
\____/|_|\__,_|_|  (_)                                 
                                                       
                                                       


===============================================================================

TABLE OF CONTENTS 

1. ABOUT
2. CONTACT
3. INSTALL INSTRUCTIONS
4. TERMS OF USE
5. CHANGE LOG

============================================

1.  ABOUT

	 This texture pack does one thing.  It removes the pumpkin blur.
	 Current and past versions may be found at www.ordinarywonders.net


=============================================

2. CONTACT

eternitymine@ordinarywonders.net 

or visit www.ordinarywonders.net for FAQ and other information.

==============================================

3. INSTALL INSTRUCTIONSONS:

	1.	Run Minecraft in the version you wish to play and that is associated with the pack you are wanting to use.
	2.	Hit the "Play" button to launch the game.
	3.	Click on the "Options" button.
	4.	Click on the "Resource Packs" button.
	5.	Click on the "Open Resource Packs Folder" button.
	6.	Copy the zipped version of the pack you wish to install.
	7.	Paste it into the Resource packs Folder.
	8.	Close the window.
	9.	Now choose your pack by clicking the arrow displayed to add it to the "selected Resource Packs" list.
	10.	The pack that is listed on the top of the list will be the dominant pack and the game will choose to use that one first. If there are no graphics for a particular block/mob available in the top pack, the game will look for textures in the second pack listed, then third and so on. So it is possible to play the game with more than one resource pack selected. The default pack is always there and can't be removed from the list.

For more detailed and alternate instructions visit the FAQ section on the Ordinary Wonders website. https://www.ordinarywonders.net/faq

  
==============================================

4. TERMS OF USE & LICENSES

THINGS YOU CAN DO:

1. You may edit, use and share any OrdinaryWonder brand packs in your own vanilla or modded resource pack as long credit is clearly given to EternityMine and a link to the OrdinaryWonders website is provided.

2. You're encouraged to use this pack in any screenshots or videos you like and are free to monetize your videos as long as you put a link to this page in the video description.

3. You're free to modify this resource pack for your own use and you're allowed to give your own modified pack to close friends, but you may not redistribute your modified pack on a public forum, server or website.
   
4. You may make this pack, in part or whole, your official private server resource pack,  you can host the pack yourself on a public or private server for Multiplayer gaming or your members may obtain the resource packs from this page only. 
    
5. Adventure map makers can freely modify the resource pack to match their map style and can provide a modified copy to go along with their map as long as you put a link back to this site with your map.
    You may use it on a commercial server (free to play with paid extras or a pay to play server),

***NOTE: If you're making money from using this or any OrdinaryWonders packs or resources, I would strongly encourage you to join my Patreon to support EternityMine and the OrdinaryWonders Brand.

THINGS YOU CANNOT DO:

1. You're not allowed to use these textures in a customizer or in any other games other than Minecraft.

2. You may never post a link to these packs behind adf.ly or any other for-profit service, a lot of work is put into these packs and I wouldn't want others to make money from all our hard work.

3. You will never post these packs (worlds, or other any Ordinary Wonder Brand files) on any other website. This site is the only authorized download location.  No hot linking any of the packs (worlds, or other any Ordinary Wonder Brand files),  for downloads or uploading them elsewhere to distribute.
   
***These rules are subject to change at any time and apply to both past and current version of packs or files.***

AUTHORIZED DOWNLOAD LOCATIONS:

You will only find the latest releases of OrdinaryWonders brand packs and files on OrdinaryWonders.net, if you've downloaded it from somewhere else, then it's probably out of date, may have bugs that have already been fixed or may have been modified or contain maleware. (note I do post packs on PlanetMinecraft, but all links lead directly here.)  Be safe and only download from the official website.

If you want someone to download this pack, please point them to OrdinaryWonders.net.


Copyright © OrdinaryWonders.net, EternityMine 2014-2024 All Rights Reserved

===============================================================================

CHANGE LOG:

2-24-02-17
-fixed the pack format so that it does not come up as an old format in the pick list.

2024-01-12
-updated the pack to work in this version
-updated the readme file
-updated the copyright
-updated the pack.png

2023-08-11
No Pumpkin Blur 1.20a
	-updated the pack to work in 1.20+

2023-01-04
No Pumpkin Blur 1.19.3b
     -updated the readme file
     -updated the pack png
     -updated the pack to work in 1.19.3

2022-02-22
No Pumpkin Blur 1.19a
Caves & Cliffs part 2
     -updated the readme file
     -optimized the pumpkin blur and added the correspondng .json file
     -updated the pack to work in 1.19+

2022-02-22
No Pumpkin Blur 1.18
Caves & Cliffs part 2
     -updated the pack to work in 1.18+

2021-09-11
No Pumpkin Blur 1.17a
Caves & Cliffs part 1
     -Removed the pumpkin blur so you have clear vision when wearing pumpkin head.